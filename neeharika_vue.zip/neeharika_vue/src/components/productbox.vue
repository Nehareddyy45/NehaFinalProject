<template>
    
     <div class="productbox">
         
        <div v-for="product in products" :key="product.id" >
                <product :product="product"/>
        </div>

     </div>

</template>

<script>

import product from "./product.vue"
export default{
  // eslint-disable-next-line vue/multi-word-component-names
    name: 'productbox',
    components: {
        product
    },
    props: {
        products: JSON
    }

}

</script>

<style>

.productbox{

    background-color: rgb(63, 11, 14);
    padding: 1em;
    color: gray;
}
</style>